function FeaturedProducts(){
    return(
        <>
        FeaturedProducts 
        </>
    )
}
export default FeaturedProducts;