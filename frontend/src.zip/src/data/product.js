const product =[{id:1,name:"light",price: 3000},{id:2,name:"fan",price:"23000"},{id:3,name:"laptop",price:"45000"},{id:4,name:"television",price:4500},{id:5,name:"almira",price:34000},
    {id:6,name:"refrigerator",price:50000},{id:7,name:"MicroWave",price:89000},{id:8,name:"chair",price:780}
]
export default product;